-- MECCHA CHAMELEON (Unreal Engine 5.6.0) custom AOB override for UE4SS.
-- The stock UE4SS (Dec-2024 experimental) signature for StaticConstructObject_Internal
-- does not match this retail 5.6.0 build, so init failed with "PS scan timed out".
--
-- This pattern is the StaticConstructObject_Internal prologue, verified against
-- PenguinHotel-Win64-Shipping.exe: it matches EXACTLY ONCE at RVA 0x15faa30, and
-- disassembly confirms it (reads const FStaticConstructObjectParameters& from rcx,
-- checks the Class ClassFlags at [Class+0xD4]). The pattern contains no absolute or
-- RIP-relative addresses, so it is stable across UE 5.6 builds.
function Register()
    return "4C 8B DC 55 53 41 56 49 8D AB 28 FE FF FF 48 81 EC C0 02 00 00 48 8B"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end
